"use strict";
$(document).ready(function () {
    $(".container").on("click", function () {
        $(this).find('.card').toggleClass("active");
    });
});